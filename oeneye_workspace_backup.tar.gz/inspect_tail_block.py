with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(410, min(421, len(lines))):
    print(f"{i+1:3d}: {repr(lines[i])}")
