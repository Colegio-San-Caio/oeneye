import struct

def inspect_fat12(img_path):
    with open(img_path, "rb") as f:
        # Read Boot Sector / BPB
        f.seek(11)
        bytes_per_sec = struct.unpack("<H", f.read(2))[0]
        sec_per_clust = f.read(1)[0]
        rsvd_sec_cnt = struct.unpack("<H", f.read(2))[0]
        num_fats = f.read(1)[0]
        root_ent_cnt = struct.unpack("<H", f.read(2))[0]
        tot_sec16 = struct.unpack("<H", f.read(2))[0]
        f.read(1) # media
        fat_sz16 = struct.unpack("<H", f.read(2))[0]
        
        # Calculate start of Root Directory
        root_dir_sector = rsvd_sec_cnt + (num_fats * fat_sz16)
        root_dir_offset = root_dir_sector * bytes_per_sec
        root_dir_size = (32 * root_ent_cnt + bytes_per_sec - 1) // bytes_per_sec * bytes_per_sec
        
        print(f"Bytes/Sector: {bytes_per_sec}")
        print(f"Root Directory Offset: {root_dir_offset}")
        
        # Read Root Directory Entries (32 bytes each)
        f.seek(root_dir_offset)
        root_data = f.read(root_dir_size)
        
        print("\n--- Root Directory Files ---")
        for i in range(0, len(root_data), 32):
            entry = root_data[i:i+32]
            if entry[0] == 0x00: # End of directory
                break
            if entry[0] == 0xE5: # Deleted file
                continue
            
            # Check attribute (offset 11) to skip volume labels if needed
            attr = entry[11]
            if attr & 0x08: # Volume ID
                continue
                
            name = entry[0:8].decode('ascii', errors='ignore').strip()
            ext = entry[8:11].decode('ascii', errors='ignore').strip()
            size = struct.unpack("<I", entry[28:32])[0]
            
            filename = f"{name}.{ext}" if ext else name
            print(f"Found: '{filename}' (Size: {size} bytes)")

inspect_fat12("mosfetq-dos.img")
