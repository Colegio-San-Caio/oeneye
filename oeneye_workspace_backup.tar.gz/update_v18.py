with open("emu.py", "r") as f:
    code = f.read()

# Update version string banner from v17.0 to v18.0
old_banner = "MOSFETQ-DOS Compact v17.0 (oeneye Trace Edition)"
new_banner = "MOSFETQ-DOS Compact v18.0 (oeneye SDK v1.0.0 Integrated Edition)"

if old_banner in code:
    code = code.replace(old_banner, new_banner)
    with open("emu.py", "w") as f:
        f.write(code)
    print("Successfully updated emulator banner to MOSFETQ-DOS v18.0!")
else:
    print("Could not locate v17.0 banner string in emu.py.")
        
