import struct

with open("oeneye-ext4.img", "rb") as f:
    # Read block size shift at superblock offset 1024 + 24
    f.seek(1048)
    s_log_block_size = struct.unpack("<I", f.read(4))[0]
    block_size = 1024 << s_log_block_size
    print(f"  [EXT4] Computed block size: {block_size} bytes")
    
    # Locate root directory structures within the first block group
    group_offset = block_size if block_size > 1024 else 2048
    f.seek(group_offset)
    sample_data = f.read(64)
    print(f"  [EXT4] Root metadata sample block: {sample_data[:16]!r}")

print("Inspection complete. Ready for file extraction commands.")
