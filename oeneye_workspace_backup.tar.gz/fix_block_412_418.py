with open("emu.py", "r") as f:
    lines = f.readlines()

# Clean up lines 412 through 418 (0-indexed 411 to 417)
new_block = [
    "    try:\n",
    "        drive_target = cmd.upper().strip()\n",
    "        print(f'Drive {drive_target} is not mounted.')\n",
    "    except Exception as e:\n",
    "        print(f'Error: {e}')\n"
]

if len(lines) >= 418:
    lines[411:418] = new_block
    print("Cleaned and structured lines 412-418 successfully!")

with open("emu.py", "w") as f:
    f.writelines(lines)
