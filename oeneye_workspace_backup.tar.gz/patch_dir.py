with open("emu.py", "r") as f:
    code = f.read()

target = 'elif cmd_upper == "DIR":'
if target in code:
    parts = code.split(target)
    header = parts[0]
    tail = parts[1]
    
    next_idx = len(tail)
    for token in ["elif ", "else:"]:
        idx = tail.find(token)
        if idx != -1 and idx < next_idx:
            next_idx = idx
            
    rest = tail[next_idx:]
    
    live_dir_code = '''elif cmd_upper == "DIR":
                boot_sector = img[:BLOCK_SIZE]
                bytes_per_sec = struct.unpack("<H", boot_sector[11:13])[0]
                rsvd_sec_cnt = struct.unpack("<H", boot_sector[14:16])[0]
                num_fats = boot_sector[16]
                root_ent_cnt = struct.unpack("<H", boot_sector[17:19])[0]
                fat_sz_16 = struct.unpack("<H", boot_sector[22:24])[0]
                if bytes_per_sec == 0:
                    bytes_per_sec = 512
                first_root_sec = rsvd_sec_cnt + (num_fats * fat_sz_16)
                root_dir_bytes = root_ent_cnt * 32
                start_offset = first_root_sec * bytes_per_sec
                end_offset = start_offset + root_dir_bytes
                print(" Volume in drive A has live FAT structure.")
                print(" Directory of A:\\")
                file_count = 0
                total_bytes = 0
                if start_offset < len(img):
                    root_data = img[start_offset:min(end_offset, len(img))]
                    for i in range(0, len(root_data), 32):
                        entry = root_data[i:i+32]
                        if len(entry) < 32 or entry[0] == 0x00:
                            break
                        if entry[0] == 0xE5 or entry[11] == 0x0F or (entry[11] & 0x08):
                            continue
                        name = entry[0:8].decode("ascii", errors="ignore").strip()
                        ext = entry[8:11].decode("ascii", errors="ignore").strip()
                        fsize = struct.unpack("<I", entry[28:32])[0]
                        filename_str = f"{name} {ext}" if ext else name
                        print(f"  {filename_str:12s} {fsize:9d}")
                        file_count += 1
                        total_bytes += fsize
                print(f"         {file_count} File(s)      {total_bytes} bytes")
                print(f"                     {len(img) - total_bytes:10d} bytes free")
    '''
    
    new_code = header + live_dir_code + rest
    with open("emu.py", "w") as f:
        f.write(new_code)
    print("SUCCESS: Fixed REPL syntax and integrated live DIR parser!")
else:
    print("Error: Could not locate DIR target.")
