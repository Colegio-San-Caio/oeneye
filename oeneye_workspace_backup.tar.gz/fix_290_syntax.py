with open("emu.py", "r") as f:
    lines = f.readlines()

# Print lines 285 to 292 for verification
for i in range(284, min(293, len(lines))):
    print(f"{i+1}: {repr(lines[i])}")

# Ensure line 290 (index 289) has a valid preceding 'if' or convert to 'if' if orphaned
if len(lines) >= 290:
    # If the preceding control flow was commented out, let's make this an 'if' statement
    lines[289] = lines[289].replace("elif", "if")

with open("emu.py", "w") as f:
    f.writelines(lines)

print("Line 290 converted to standalone if statement!")
