with open("emu.py", "r") as f:
    lines = f.readlines()

# Clean up any stray unindented try statements around line 449-450
cleaned_lines = []
for i, line in enumerate(lines):
    if i == 448 and line.strip() == "try:":
        cleaned_lines.append("        try:\n")
    else:
        cleaned_lines.append(line)

# Inject the Fermat J_3 filtration protocol into the environment state handler
fermat_j3_code = [
    "\n        # Fermat-theoretic J_3 filtration operator applied to state weights\n",
    "        fermat_prime_mod = 3\n",
    "        env_state['j3_filtered'] = [q_val * (1.0 / (1.0 + (i % fermat_prime_mod))) for i, q_val in enumerate(env_state.get('q_coords', [1.0, 0.0, 0.0, 0.0, 0.0]))]\n"
]

# Insert just before the FAT parsing try/except block
target_idx = min(450, len(cleaned_lines))
final_lines = cleaned_lines[:target_idx] + fermat_j3_code + cleaned_lines[target_idx:]

with open("emu.py", "w") as f:
    f.writelines(final_lines)

print("Successfully integrated Fermat J_3 filtration and cleaned syntax blocks!")
