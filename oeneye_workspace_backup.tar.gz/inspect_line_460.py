with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(450, min(471, len(lines))):
    print(f"{i+1:3d}: {repr(lines[i])}")
