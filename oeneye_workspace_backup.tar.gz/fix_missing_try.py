with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 413:
    # Insert a try: statement right above the except block on line 413
    lines.insert(412, "    try:\n")
    print("Inserted matching try block!")

with open("emu.py", "w") as f:
    f.writelines(lines)
