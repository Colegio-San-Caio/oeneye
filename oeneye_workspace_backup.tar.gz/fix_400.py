with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 400:
    idx = 399  # 0-indexed for line 400
    if "except" in lines[idx] and not lines[idx].strip().startswith("#"):
        lines[idx] = "# " + lines[idx]
        print("Neutralized orphaned except block at line 400!")

with open("emu.py", "w") as f:
    f.writelines(lines)
