with open("emu.py", "r") as f:
    lines = f.readlines()

# Let's inspect and convert dangling try statements or comment them out if orphaned
new_lines = []
for i, line in enumerate(lines):
    # If a line has a standalone try: check if there's an except/finally within the next 15 lines
    if line.strip() == "try:":
        has_handler = False
        for j in range(i + 1, min(i + 15, len(lines))):
            if "except" in lines[j] or "finally" in lines[j]:
                has_handler = True
                break
        if not has_handler:
            print(f"Neutralizing orphaned try block at line {i+1}")
            new_lines.append("# " + line) # Comment out orphaned try
            continue
    new_lines.append(line)

with open("emu.py", "w") as f:
    f.writelines(new_lines)

print("Scanned and cleaned orphaned try blocks!")
