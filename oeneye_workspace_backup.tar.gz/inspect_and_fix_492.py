with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(max(0, 480), min(len(lines), 505)):
    print(f"{i+1:3d}: {repr(lines[i])}")
