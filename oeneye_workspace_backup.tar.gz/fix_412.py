with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 412:
    idx = 411  # 0-indexed for line 412
    if "else:" in lines[idx] and not lines[idx].strip().startswith("#"):
        lines[idx] = "# " + lines[idx]
        print("Neutralized orphaned else block at line 412!")

with open("emu.py", "w") as f:
    f.writelines(lines)
