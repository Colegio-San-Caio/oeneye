with open("emu.py", "r") as f:
    lines = f.readlines()

new_lines = []
skip = False
for line in lines:
    if "elif ah == 0x0A:" in line:
        skip = True
        # Insert the correct clean block here
        new_lines.append("        elif ah == 0x0A:\n")
        new_lines.append("            import sys\n")
        new_lines.append("            line_input = sys.stdin.readline().rstrip('\\n') + '\\r'\n")
        new_lines.append("            ds = regs.get('DS', 0)\n")
        new_lines.append("            dx = regs.get('DX', 0)\n")
        new_lines.append("            ds_dx = (ds << 4) + dx\n")
        new_lines.append("            max_len = memory[ds_dx] if ds_dx < len(memory) else 30\n")
        new_lines.append("            input_bytes = line_input.encode('ascii', errors='ignore')[:max_len]\n")
        new_lines.append("            memory[ds_dx + 1] = len(input_bytes)\n")
        new_lines.append("            for idx, b in enumerate(input_bytes):\n")
        new_lines.append("                memory[ds_dx + 2 + idx] = b\n")
        new_lines.append("            return True\n")
    elif skip and "return True" in line:
        skip = False
        continue
    elif skip:
        continue
    else:
        new_lines.append(line)

with open("emu.py", "w") as f:
    f.writelines(new_lines)

print("Successfully patched emu.py with clean syntax!")
