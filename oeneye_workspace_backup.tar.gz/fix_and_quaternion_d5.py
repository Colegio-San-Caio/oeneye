with open("emu.py", "r") as f:
    lines = f.readlines()

# Keep lines up to 414, remove the duplicate trailing block (415-420), 
# and inject the Quaternion D^5 mapping structure.
new_lines = lines[:414] + [
    "        # Quaternion D^5 Hypercomplex Mapping Protocol\n",
    "        # Replaces standard projections with a 5-dimensional quaternion coordinate transform\n",
    "        q_vector = [float(idx), 1.0, 0.0, 0.0, 0.0]  # D^5 space embedding\n",
    "        norm_d5 = sum(x**2 for x in q_vector) ** 0.5\n",
    "        if norm_d5 > 0:\n",
    "            env_state['q_coords'] = [x / norm_d5 for x in q_vector]\n"
] + lines[421:]

with open("emu.py", "w") as f:
    f.writelines(new_lines)

print("Integrated Quaternion D^5 mapping and cleaned duplicate block successfully!")
