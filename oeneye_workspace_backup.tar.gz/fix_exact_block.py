with open("emu.py", "r") as f:
    lines = f.readlines()

# Rewrite lines 409 to 414 with precise indentation
lines[409] = "    if idx < len(mounted):\n"
lines[410] = "        env_state[\"active_idx\"] = idx\n"
lines[411] = "        print(f\"Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}\")\n"
lines[412] = "    else:\n"
lines[413] = "        drive_target = cmd.upper().strip()\n"
lines[414] = "        print(f\"Drive {drive_target} is not mounted.\")\n"

print("Rewrote exact block indentation!")

with open("emu.py", "w") as f:
    f.writelines(lines)
