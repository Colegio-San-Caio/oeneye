with open("emu.py", "r") as f:
    lines = f.readlines()

# Fix indentation from line 194 onwards until the next function definition
for i in range(193, len(lines)):
    stripped = lines[i].lstrip()
    if not stripped:
        continue
    if stripped.startswith("def ") or stripped.startswith("if __name__"):
        break
    # Align to standard 8 spaces (two levels inside the function)
    lines[i] = "        " + stripped

with open("emu.py", "w") as f:
    f.writelines(lines)

print("Trailing block indentation realigned!")
