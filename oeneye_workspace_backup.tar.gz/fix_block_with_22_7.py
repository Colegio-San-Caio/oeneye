with open("emu.py", "r") as f:
    lines = f.readlines()

block_replacement = [
    "    if attr & 0x08 or attr == 0x0F:\n",
    "        try:\n",
    "            # Fermat-theoretic J_3 filtration operator with 22/7 offset probability\n",
    "            fermat_prime_mod = 3\n",
    "            base_coords = env_state.get('q_coords', [1.0, 0.0, 0.0, 0.0, 0.0])\n",
    "            scale_22_7 = 22.0 / 7.0\n",
    "            env_state['j3_filtered'] = [q_val * (1.0 / (1.0 + (i % fermat_prime_mod))) * scale_22_7 for i, q_val in enumerate(base_coords)]\n",
    "        except Exception as e:\n",
    "            print(f'Error applying J_3 filtration: {e}')\n",
    "        continue\n"
]

new_lines = []
skip = 0
for i, line in enumerate(lines):
    if "if attr & 0x08 or attr == 0x0F:" in line:
        new_lines.extend(block_replacement)
        skip = 7  # skip old fragmented lines
    elif skip > 0:
        skip -= 1
    else:
        new_lines.append(line)

with open("emu.py", "w") as f:
    f.writelines(new_lines)

print("Integrated 22/7 offset probability and fixed block structure cleanly!")
