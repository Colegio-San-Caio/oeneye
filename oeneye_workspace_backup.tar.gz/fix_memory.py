with open("emu.py", "r") as f:
    code = f.read()

# Ensure memory is properly sized inside handle_interrupt or the test block
old_init = "memory = locals().get(\"memory\", bytearray(65536))"
new_init = """memory = locals().get("memory", None)
            if memory is None or len(memory) < 0x10000:
                memory = bytearray(0x10000)
                locals()["memory"] = memory"""

code = code.replace('memory = locals().get("memory", bytearray(65536))', new_init)

with open("emu.py", "w") as f:
    f.write(code)

print("Ensured robust 64KB memory allocation!")
