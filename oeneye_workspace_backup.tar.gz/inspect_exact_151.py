with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(144, min(156, len(lines))):
    print(f"{i+1}: {ascii(lines[i])}")
