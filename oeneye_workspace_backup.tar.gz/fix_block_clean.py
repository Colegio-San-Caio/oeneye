with open("emu.py", "r") as f:
    code = f.read()

# Let's target the exact text block around line 409-414 and replace it cleanly
target_block = """    if idx < len(mounted):
        env_state['active_idx'] = idx
        print(f'Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}')
    else:
        drive_target = cmd.upper().strip()
        print(f'Drive {drive_target} is not mounted.')"""

# If we want a foolproof approach, let's just inspect and write a clean script segment.
print("Ready to apply block replacement.")
