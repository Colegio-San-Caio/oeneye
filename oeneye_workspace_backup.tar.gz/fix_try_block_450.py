with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 465:
    # Insert 'try:' before the entry parsing loop/logic
    lines.insert(449, "        try:\n")
    print("Injected missing try: block successfully!")

with open("emu.py", "w") as f:
    f.writelines(lines)
