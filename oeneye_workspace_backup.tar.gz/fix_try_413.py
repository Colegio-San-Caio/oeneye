with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 413:
    # Insert an except block right before line 413 (0-indexed 412)
    lines.insert(412, "except Exception as e:\n")
    lines.insert(413, "    print(f'Error: {e}')\n")
    print("Added except handler for the try block!")

with open("emu.py", "w") as f:
    f.writelines(lines)
