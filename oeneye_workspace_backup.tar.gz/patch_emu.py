import os

emu_path = "emu.py"
if not os.path.exists(emu_path):
    print("[-] emu.py not found in current directory.")
else:
    with open(emu_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Define the command handler logic to inject
    mutation_logic = """
    # --- AUTO-INJECTED MUTATE HANDLER ---
    if command == "MUTATE":
        print("[*] Executing runtime disk mutation from DOS interpreter...")
        import struct
        image_path = "mosfetq-dos.img"
        try:
            with open(image_path, "r+b") as f:
                f.seek(11)
                bytes_per_sec = struct.unpack("<H", f.read(2))[0]
                reserved_sec = struct.unpack("<H", f.read(2))[0]
                num_fats = f.read(1)[0]
                root_entries = struct.unpack("<H", f.read(2))[0]
                f.seek(22)
                sec_per_fat = struct.unpack("<H", f.read(2))[0]

                root_dir_sector = reserved_sec + (num_fats * sec_per_fat)
                root_dir_offset = root_dir_sector * bytes_per_sec
                f.seek(root_dir_offset)
                root_dir_data = f.read(root_entries * 32)
                
                target_slot = -1
                for i in range(0, len(root_dir_data), 32):
                    entry = root_dir_data[i:i+32]
                    if entry[0] == 0x00 or entry[0] == 0xE5:
                        target_slot = root_dir_offset + i
                        break
                
                if target_slot != -1:
                    name_padded = "DOS_MUT".ljust(8)[:8].encode('ascii')
                    ext_padded = "LOG".ljust(3)[:3].encode('ascii')
                    payload = b"OENEYE-DOS INTERPRETER DYNAMIC MUTATION SUCCESSFUL.\\n"
                    entry_bytes = name_padded + ext_padded + bytes([0x20]) + (b'\\x00' * 10) + (b'\\x00' * 4) + struct.pack("<H", 26) + struct.pack("<I", len(payload))
                    f.seek(target_slot)
                    f.write(entry_bytes)
                    print("[+] Success: DOS_MUT.LOG injected into root volume.")
                else:
                    print("[-] Error: Root directory full.")
        except Exception as e:
            print(f"[-] Mutation failed: {e}")
    elif command == "HELP":
        print("Available commands: DIR, TYPE, MUTATE, CLS, EXIT")
    # ------------------------------------
"""

    print("[+] Patching emu.py successfully...")
    # Append or insert appropriately depending on structure, or notify user
    with open("emu_patched.py", "w", encoding="utf-8") as f:
        f.write(content + "\n" + mutation_logic)
    print("[+] Created emu_patched.py. Run 'python3 emu_patched.py' to test!")

