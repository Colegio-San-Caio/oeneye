with open("oeneye-ext4.img", "rb") as f:
    f.seek(1048)
    block_size = 1024 << int.from_bytes(f.read(4), "little")
    
    start_block = 1293
    f.seek(start_block * block_size)
    header_data = f.read(128)
    
    print("  [EXT4] Inspecting test.ppm Header at Block 1293:")
    print(f"    -> Raw ASCII: {header_data[:64].decode('utf-8', errors='ignore')}")
    print(f"    -> Raw Hex: {header_data[:32].hex()}")
