with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 413:
    idx = 412  # 0-indexed for line 413
    lines[idx] = lines[idx].lstrip()
    print("Stripped unexpected indentation from line 413!")

with open("emu.py", "w") as f:
    f.writelines(lines)
