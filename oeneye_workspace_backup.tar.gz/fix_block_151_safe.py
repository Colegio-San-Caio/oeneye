with open("emu.py", "r") as f:
    text = f.read()

# Locate and replace the block cleanly using exact string matching
old_snippet = """    if idx < len(mounted):
        env_state['active_idx'] = idx
        print(f'Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}')
    else:
        drive_target = cmd.upper().strip()
        print(f'Drive {drive_target} is not mounted.')"""

# If there are slight whitespace variations, let's replace by writing a clean replacement function
with open("emu.py", "r") as f:
    lines = f.readlines()

new_lines = []
skip = 0
for i, line in enumerate(lines):
    if "if idx < len(mounted):" in line and i > 140:
        new_lines.append("    if idx < len(mounted):\n")
        new_lines.append("        env_state['active_idx'] = idx\n")
        new_lines.append("        print(f'Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}')\n")
        new_lines.append("    else:\n")
        new_lines.append("        drive_target = cmd.upper().strip()\n")
        new_lines.append("        print(f'Drive {drive_target} is not mounted.')\n")
        skip = 5
    elif skip > 0:
        skip -= 1
    else:
        new_lines.append(line)

with open("emu.py", "w") as f:
    f.writelines(new_lines)

print("Applied safe block normalization around line 151!")
