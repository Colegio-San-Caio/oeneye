with open("emu.py", "r") as f:
    lines = f.readlines()

# Replace lines 412 through 418 (0-indexed 411 to 417) with a clean else block
new_block = [
    "    else:\n",
    "        drive_target = cmd.upper().strip()\n",
    "        print(f'Drive {drive_target} is not mounted.')\n"
]

if len(lines) >= 418:
    lines[411:418] = new_block
    print("Replaced try block with correct else structure!")

with open("emu.py", "w") as f:
    f.writelines(lines)
