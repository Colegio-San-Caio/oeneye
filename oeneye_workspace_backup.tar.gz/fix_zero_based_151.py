with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 156:
    # Index 150 corresponds to line 151
    lines[150] = "    if idx < len(mounted):\n"
    lines[151] = "        env_state['active_idx'] = idx\n"
    lines[152] = "        print(f'Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}')\n"
    lines[153] = "    else:\n"
    lines[154] = "        drive_target = cmd.upper().strip()\n"
    lines[155] = "        print(f'Drive {drive_target} is not mounted.')\n"
    print("Corrected zero-based block indentation perfectly!")

with open("emu.py", "w") as f:
    f.writelines(lines)
