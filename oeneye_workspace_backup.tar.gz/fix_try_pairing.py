with open("emu.py", "r") as f:
    lines = f.readlines()

# Search backwards from line 283 (index 282) to find an active try:
for i in range(282, -1, -1):
    if lines[i].strip() == "try:":
        lines[i] = "# " + lines[i]
        print(f"Commented out orphaned try: at line {i+1}")
        break

with open("emu.py", "w") as f:
    f.writelines(lines)

print("Orphaned try pairing fixed!")
