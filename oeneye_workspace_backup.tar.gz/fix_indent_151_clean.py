with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 155:
    lines[150] = "    if idx < len(mounted):\n"
    lines[151] = "        env_state['active_idx'] = idx\n"
    lines[152] = "        print(f'Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}')\n"
    lines[153] = "    else:\n"
    lines[154] = "        drive_target = cmd.upper().strip()\n"
    print("Cleaned indentation for lines 151-155!")

with open("emu.py", "w") as f:
    f.writelines(lines)
