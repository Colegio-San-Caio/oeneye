with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(129, min(142, len(lines))):
    print(f"{i+1}: {repr(lines[i])}")
