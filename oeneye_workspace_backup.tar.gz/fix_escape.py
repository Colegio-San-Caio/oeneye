with open("emu.py", "r") as f:
    code = f.read()

# Fix the trailing backslash escape issue in the print statement
code = code.replace('print(" Directory of A:\\")', 'print(" Directory of A:\\\\")')

with open("emu.py", "w") as f:
    f.write(code)

print("SUCCESS: Fixed string escape syntax!")
