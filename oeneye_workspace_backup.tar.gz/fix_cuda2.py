import re
with open("emu.py", "r") as f:
    code = f.read()

# Check for an actual call, ignoring the def line
if "\n" + "    oeneyecuda_cmd(cmd)" in code.replace("def oeneyecuda_cmd(cmd):", ""):
    print("Already wired.")
else:
    m = re.search(r'^(\s*)elif cmd\.upper\(\)\.startswith\("OENEYECUDA"\):', code, flags=re.M)
    if m:
        ind = m.group(1)
        new = f'{ind}elif cmd.upper().startswith("OENEYECUDA"):\n{ind}    oeneyecuda_cmd(cmd)\n'
        code = code[:m.start()] + new + code[m.start():]
        with open("emu.py", "w") as f:
            f.write(code)
        print("OENEYECUDA now runs real benchmarks.")
    else:
        print("Could not find the OENEYECUDA elif.")
