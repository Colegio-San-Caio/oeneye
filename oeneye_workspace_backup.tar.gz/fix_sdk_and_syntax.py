with open("emu.py", "r") as f:
    lines = f.readlines()

cleaned_lines = []
for i, line in enumerate(lines):
    # Ensure the main loop's outer exception handler is cleanly aligned
    if "except (KeyboardInterrupt, EOFError):" in line:
        cleaned_lines.append("except (KeyboardInterrupt, EOFError):\n")
    else:
        cleaned_lines.append(line)

# Append the Q-DOS SDK module layer for external tool and extension binding
sdk_module = [
    "\n# MOSFETQ-DOS Software Development Kit (SDK) Layer\n",
    "class QDOSSDK:\n",
    "    def __init__(self, env):\n",
    "        self.env = env\n",
    "    def register_extension(self, name, callback):\n",
    "        print(f'  [SDK] Registering runtime extension: {name}')\n",
    "        self.env[name] = callback\n",
    "        return True\n",
    "\n# Initialize active SDK instance\n",
    "q_sdk = QDOSSDK(env_state if 'env_state' in globals() else {})\n"
]

cleaned_lines.extend(sdk_module)

with open("emu.py", "w") as f:
    f.writelines(cleaned_lines)

print("Integrated SDK layer and resolved line 492 syntax successfully!")
