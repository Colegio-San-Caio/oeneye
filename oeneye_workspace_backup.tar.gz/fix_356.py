with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 356:
    idx = 355  # 0-indexed for line 356
    if "elif" in lines[idx]:
        lines[idx] = lines[idx].replace("elif", "if")
        print("Converted line 356 elif to if!")

with open("emu.py", "w") as f:
    f.writelines(lines)
