with open("emu.py", "r") as f:
    lines = f.readlines()

# Clean replacement matching the 4-space loop nesting depth (8 spaces total for inner block)
block_replacement = [
    "        if attr & 0x08 or attr == 0x0F:\n",
    "            try:\n",
    "                # Fermat-theoretic J_3 filtration operator with 22/7 offset probability\n",
    "                fermat_prime_mod = 3\n",
    "                base_coords = env_state.get('q_coords', [1.0, 0.0, 0.0, 0.0, 0.0])\n",
    "                scale_22_7 = 22.0 / 7.0\n",
    "                env_state['j3_filtered'] = [q_val * (1.0 / (1.0 + (i % fermat_prime_mod))) * scale_22_7 for i, q_val in enumerate(base_coords)]\n",
    "            except Exception as e:\n",
    "                print(f'Error applying J_3 filtration: {e}')\n",
    "            continue\n"
]

new_lines = []
skip = 0
for i, line in enumerate(lines):
    if "if attr & 0x08 or attr == 0x0F:" in line:
        new_lines.extend(block_replacement)
        skip = 7  # skip old fragmented lines
    elif skip > 0:
        skip -= 1
    else:
        new_lines.append(line)

# Inject CNC Horizon Berlin logo banner logic into startup routine if present
final_lines = []
logo_banner = [
    "\n    # CNC Horizon Berlin Logo Runtime Signature (Gear & Feather Geometric Core)\n",
    "    print('  [(( ( * ) ))] CNC HORIZON BERLIN -- Q-DOS HYPERCOMPLEX ENGINE')\n",
    "    print('  -------------------------------------------------------\\n')\n"
]

for line in final_lines or new_lines:
    final_lines.append(line)
    if "def boot" in line or "def main" in line or "os_init" in line.lower():
        final_lines.extend(logo_banner)

with open("emu.py", "w") as f:
    f.writelines(final_lines)

print("Integrated logo logic, 22/7 offset, Fermat J_3, and fixed indentation!")
