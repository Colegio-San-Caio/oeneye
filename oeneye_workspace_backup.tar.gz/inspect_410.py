with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(409, min(420, len(lines))):
    print(f"{i+1}: {repr(lines[i])}")
