with open("emu.py", "r") as f:
    lines = f.readlines()

# Uncomment and fix indentation for line 183 (index 182)
if len(lines) >= 184:
    lines[182] = "        try:\n"
    # Ensure lines inside the try block are indented correctly
    for i in range(183, min(195, len(lines))):
        stripped = lines[i].lstrip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("except") or stripped.startswith("else:") or stripped.startswith("elif") or stripped.startswith("def "):
            break
        lines[i] = "            " + stripped

with open("emu.py", "w") as f:
    f.writelines(lines)

print("Try block structure restored!")
