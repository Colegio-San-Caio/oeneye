with open("emu.py", "r") as f:
    code = f.read()

# Fix the RUN command block to avoid global statement ordering issues
old_run = """        elif cmd.upper().startswith("RUN "):
            filename = cmd.split()[1]
            import os
            if os.path.exists(filename):
                with open(filename, "rb") as bin_file:
                    bin_data = bin_file.read()
                
                global memory
                if "memory" not in globals():
                    globals()["memory"] = bytearray(0x10000)
                memory = globals()["memory"]"""

new_run = """        elif cmd.upper().startswith("RUN "):
            filename = cmd.split()[1]
            import os
            if os.path.exists(filename):
                with open(filename, "rb") as bin_file:
                    bin_data = bin_file.read()
                
                if "memory" not in globals():
                    globals()["memory"] = bytearray(0x10000)
                memory = globals()["memory"]"""

code = code.replace(old_run, new_run)

with open("emu.py", "w") as f:
    f.write(code)

print("Fixed RUN command loader scope!")

# Create a simple test .COM binary file (e.g. test.com)
# For now, let's write a dummy binary file to test the loader message
with open("test.com", "wb") as f:
    f.write(b"\\x90\\x90\\xCD\\x20") # NOP, NOP, INT 20h (Terminate)

print("Created sample test.com binary file!")
