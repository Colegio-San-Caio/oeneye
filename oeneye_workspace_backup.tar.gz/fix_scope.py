with open("emu.py", "r") as f:
    code = f.read()

# Fix TEST0A to use global memory and print accurately
old_test = """        elif cmd.upper() == "TEST0A":
            print("--- Testing INT 21h AH=0Ah (Buffered Input) ---")
            memory = locals().get("memory", bytearray(65536))
            ds_dx = 0x0500  # Safe offset within 64KB memory
            memory[ds_dx] = 30  # Max buffer size
            
            regs = {"AX": 0x0A00, "DS": 0x0000, "DX": 0x0500}
            print("Enter a string to test keyboard buffering:")
            handle_interrupt(0x21, regs, memory)
            
            length_read = memory[ds_dx + 1]
            print(f"\\nBytes read into buffer: {length_read}")
            result_str = "".join(chr(memory[ds_dx + 2 + i]) for i in range(length_read)).rstrip("\\r")
            print(f"Stored buffer content: \\"{result_str}\\"")"""

new_test = """        elif cmd.upper() == "TEST0A":
            print("--- Testing INT 21h AH=0Ah (Buffered Input) ---")
            global memory
            if "memory" not in globals():
                memory = bytearray(0x10000)
            ds_dx = 0x0500
            memory[ds_dx] = 30  # Max buffer size
            
            regs = {"AX": 0x0A00, "DS": 0x0000, "DX": 0x0500}
            handle_interrupt(0x21, regs, memory)
            
            length_read = memory[ds_dx + 1]
            print(f"\\nBytes read into buffer: {length_read}")
            result_str = "".join(chr(memory[ds_dx + 2 + i]) for i in range(length_read)).rstrip("\\r")
            print(f"Stored buffer content: \\"{result_str}\\"")"""

code = code.replace(old_test, new_test)

# Also ensure handle_interrupt uses global/passed memory cleanly for AH=0Ah
old_ah0a = """        elif ah == 0x0A:
            import sys
            line_input = input("DOS Keyboard Input > ") + '\\r'
            ds = regs.get('DS', 0)
            dx = regs.get('DX', 0)
            ds_dx = (ds << 4) + dx
            # Ensure memory is large enough
            if ds_dx + 256 > len(memory):
                memory.extend(b'\\x00' * (ds_dx + 256 - len(memory)))
            max_len = memory[ds_dx] if memory[ds_dx] > 0 else 30
            input_bytes = line_input.encode('ascii', errors='ignore')[:max_len]
            memory[ds_dx + 1] = len(input_bytes)
            for idx, b in enumerate(input_bytes):
                memory[ds_dx + 2 + idx] = b
            return True"""

new_ah0a = """        elif ah == 0x0A:
            line_input = input("DOS Keyboard Input > ") + '\\r'
            ds = regs.get('DS', 0)
            dx = regs.get('DX', 0)
            ds_dx = (ds << 4) + dx
            if ds_dx + 256 > len(memory):
                memory.extend(b'\\x00' * (ds_dx + 256 - len(memory)))
            max_len = memory[ds_dx] if memory[ds_dx] > 0 else 30
            input_bytes = line_input.encode('ascii', errors='ignore')[:max_len]
            memory[ds_dx + 1] = len(input_bytes)
            for idx, b in enumerate(input_bytes):
                memory[ds_dx + 2 + idx] = b
            return True"""

code = code.replace(old_ah0a, new_ah0a)

with open("emu.py", "w") as f:
    f.write(code)

print("Scope and memory sharing fixed!")
