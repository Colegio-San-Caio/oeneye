with open("emu.py", "r") as f:
    code = f.read()

target = 'elif cmd_upper.startswith("GEMINI"):'
type_block = '''elif cmd_upper.startswith("TYPE "):
            filename = cmd_in[5:].strip().upper()
            if "README.TXT" in filename:
                print("Contents of README.TXT:")
                print("  MOSFETQ DOS is a tiny DOS-style OS: boot sector, kernel and shell.")
                print("  All files here are built into the kernel image (no disk filesystem yet).")
            elif "TODO.TXT" in filename:
                print("Contents of TODO.TXT:")
                print("  1. FAT12 driver (INT 13h) 2. RUN for .COM files 3. INT 21h services")
            else:
                print(f"File not found: {filename}")
        elif cmd_upper.startswith("GEMINI"):'''

if target in code and 'startswith("TYPE ")' not in code:
    code = code.replace(target, type_block, 1)
    with open("emu.py", "w") as f:
        f.write(code)
    print("SUCCESS: Added TYPE command handler!")
else:
    print("Note: TYPE handler already present or target not found.")
