with open("emu.py", "r") as f:
    lines = f.readlines()

new_lines = []
skip = 0
for i, line in enumerate(lines):
    if "if idx < len(mounted):" in line:
        new_lines.append("    if idx < len(mounted):\n")
        new_lines.append("        env_state['active_idx'] = idx\n")
        new_lines.append("        print(f'Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}')\n")
        new_lines.append("    else:\n")
        new_lines.append("        drive_target = cmd.upper().strip()\n")
        new_lines.append("        print(f'Drive {drive_target} is not mounted.')\n")
        skip = 5 # skip the next few old lines belonging to this block
    elif skip > 0:
        skip -= 1
    else:
        new_lines.append(line)

with open("emu.py", "w") as f:
    f.writelines(new_lines)

print("Replaced conditional block cleanly from source matching!")
