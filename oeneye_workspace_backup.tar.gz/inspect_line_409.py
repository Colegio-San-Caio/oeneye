with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(404, min(416, len(lines))):
    print(f"{i+1:3d}: {repr(lines[i])}")
