with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 156:
    lines[148] = "                if len(arg) == 1 and arg in \"ABCD\":\n"
    lines[149] = "                    idx = ord(arg) - ord(\"A\")\n"
    lines[150] = "                    if idx < len(mounted):\n"
    lines[151] = "                        env_state['active_idx'] = idx\n"
    lines[152] = "                        print(f'Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}')\n"
    lines[153] = "                    else:\n"
    lines[154] = "                        drive_target = cmd.upper().strip()\n"
    lines[155] = "                        print(f'Drive {drive_target} is not mounted.')\n"
    print("Restored conditional header and indented block successfully!")

with open("emu.py", "w") as f:
    f.writelines(lines)
