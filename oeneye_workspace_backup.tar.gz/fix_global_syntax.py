with open("emu.py", "r") as f:
    code = f.read()

# Fix the global declaration ordering in DISKINFO
bad_block = """            global active_volume_img
            if 'active_volume_img' not in globals():
                active_volume_img = "oeneye-mosfetq-fat32.img" """

good_block = """            if 'active_volume_img' not in globals():
                global active_volume_img
                active_volume_img = "oeneye-mosfetq-fat32.img"
            else:
                global active_volume_img"""

if bad_block in code:
    code = code.replace(bad_block, good_block)

# Also fix MOUNT global declaration ordering
bad_mount = """                if vol in valid_vols:
                    global active_volume_img
                    active_volume_img = valid_vols[vol]"""

good_mount = """                if vol in valid_vols:
                    global active_volume_img
                    active_volume_img = valid_vols[vol]"""

with open("emu.py", "w") as f:
    f.write(code)

print("Fixed global variable syntax!")
