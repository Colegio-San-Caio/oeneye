with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 184:
    idx = 183  # 0-indexed for line 184
    lines[idx] = lines[idx].lstrip()
    print("Stripped unexpected indentation from line 184!")

with open("emu.py", "w") as f:
    f.writelines(lines)
