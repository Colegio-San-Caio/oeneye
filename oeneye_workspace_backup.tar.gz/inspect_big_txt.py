import os

def inspect_big_txt(image_path="mosfetq-dos.img"):
    if not os.path.exists(image_path):
        print(f"[-] Image not found: {image_path}. Please ensure it's downloaded.")
        return

    with open(image_path, "rb") as f:
        f.seek(11)
        bytes_per_sector = int.from_bytes(f.read(2), "little")
        reserved_sectors = int.from_bytes(f.read(2), "little")
        num_fats = f.read(1)[0]
        root_entry_count = int.from_bytes(f.read(2), "little")
        f.seek(22)
        sectors_per_fat = int.from_bytes(f.read(2), "little")

        root_dir_sector = reserved_sectors + (num_fats * sectors_per_fat)
        root_dir_offset = root_dir_sector * bytes_per_sector
        root_dir_size = (root_entry_count * 32)

        f.seek(root_dir_offset)
        root_dir_data = f.read(root_dir_size)

        found = False
        for i in range(0, len(root_dir_data), 32):
            entry = root_dir_data[i:i+32]
            filename = entry[0:11]
            if filename.startswith(b"BIG     TXT"):
                found = True
                starting_cluster = int.from_bytes(entry[26:28], "little")
                file_size = int.from_bytes(entry[28:32], "little")
                print(f"[+] Found BIG.TXT:")
                print(f"    - Starting Cluster: {starting_cluster}")
                print(f"    - File Size: {file_size} bytes")
                break
        
        if not found:
            print("[-] BIG.TXT not found in root directory.")

if __name__ == "__main__":
    inspect_big_txt()
