import struct

filename = "oeneye-00x00.img"

with open(filename, "rb") as f:
    boot_sector = f.read(512)
    file_data = f.read()
    print(f"File size: {len(file_data) + 512} bytes")
    
    signature = boot_sector[510:512]
    print(f"Boot Signature (Hex): {signature.hex()}")
    
    if signature == b'\x55\xaa':
        print("-> Valid MBR boot signature (0x55AA) found!")
    else:
        print("-> No standard MBR boot signature found (might be a raw filesystem or custom header).")
    
    print("\n--- Partition Table Entries ---")
    for i in range(4):
        offset = 446 + (i * 16)
        partition_entry = boot_sector[offset:offset+16]
        partition_type = partition_entry[4]
        start_sector = struct.unpack('<I', partition_entry[8:12])[0]
        num_sectors = struct.unpack('<I', partition_entry[12:16])[0]
        
        if num_sectors > 0:
            print(f"Partition {i+1}: Type 0x{partition_type:02x}, Start Sector: {start_sector}, Size Sectors: {num_sectors}")
        else:
            print(f"Partition {i+1}: Unused / Empty")
