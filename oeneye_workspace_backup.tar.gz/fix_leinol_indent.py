with open("emu.py", "r") as f:
    lines = [line.rstrip('\n') for line in f.readlines()]

# Retain stable code up to the execution boundary
clean_lines = [l for i, l in enumerate(lines) if i < 478]

# Properly indented Leinöl viscosity and polymer smoothing block
leinol_block = [
    "    try:",
    "        # Leinöl (Linseed Oil) Polymer Viscosity & Smoothing Coefficient",
    "        leinol_viscosity_factor = 0.985",
    "        if 'env_state' in globals() and 'tartan_sett_matrix' in env_state:",
    "            env_state['leinol_smoothed'] = [v * leinol_viscosity_factor for v in env_state['tartan_sett_matrix']]",
    "    except Exception as leinol_err:",
    "        print(f'Leinöl polymer warning: {leinol_err}')",
    "except (KeyboardInterrupt, EOFError):",
    "    print('\\n[MOSFETQ-DOS] Session stabilized under Leinöl polymer seal.')",
    "    break"
]

clean_lines.extend(leinol_block)

with open("emu.py", "w") as f:
    f.write('\n'.join(clean_lines) + '\n')

print("Integrated Leinöl smoothing factor and aligned indentation successfully!")
