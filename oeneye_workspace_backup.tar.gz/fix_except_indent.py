with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 194:
    # Ensure the print statement under except on line 194 is indented correctly
    lines[193] = "                print(f\"Volume read error: {e}\")\n"

with open("emu.py", "w") as f:
    f.writelines(lines)

print("Except block body indentation fixed!")
