with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(275, 292):
    if i < len(lines):
        print(f"{i+1}: {repr(lines[i])}")
        if lines[i].strip() in ("try:", "except:", "else:"):
            lines[i] = "# " + lines[i]

with open("emu.py", "w") as f:
    f.writelines(lines)

print("Checked and cleaned around line 290!")
