with open("emu.py", "r") as f:
    content = f.read()

import re

# Match the while True loop and replace its inner block cleanly
pattern = r'(while\s+True\s*:\s*\n)(?:\s*(?:chunk.*?|if.*?|break.*?|h\.update.*?)\n)*'
replacement = r'\1            chunk = f.read(1 << 20)\n            if not chunk:\n                break\n            h.update(chunk)\n'

new_content = re.sub(pattern, replacement, content)

with open("emu.py", "w") as f:
    f.write(new_content)

print("emu.py cleaned and fixed!")
