with open("emu.py", "r") as f:
    lines = f.readlines()

# Truncate clean up to line 480 and cleanly append the inertia damping handler
clean_lines = lines[:480]

inertia_and_exit = [
    "\n    except (KeyboardInterrupt, EOFError):\n",
    "        # Inertia damping & momentum factor for graceful session teardown\n",
    "        inertia_factor = 0.95\n",
    "        if 'env_state' in globals() and 'q_coords' in env_state:\n",
    "            env_state['q_coords'] = [v * inertia_factor for v in env_state['q_coords']]\n",
    "        print('\\n[MOSFETQ-DOS] Inertia damping applied. Session terminated.')\n",
    "        break\n"
]

clean_lines.extend(inertia_and_exit)

with open("emu.py", "w") as f:
    f.writelines(clean_lines)

print("Integrated Inertia momentum factor and aligned exception indentation successfully!")
