with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 195:
    # Ensure try: is correct
    lines[182] = "        try:\n"
    lines[183] = "            with open(target, \"r+b\") as bf:\n"
    
    # Indent the body lines under 'with'
    for i in range(184, 192):
        stripped = lines[i].lstrip()
        if stripped and not stripped.startswith("except") and not stripped.startswith("else:"):
            lines[i] = "                " + stripped

    # Insert an except handler to satisfy the try block
    lines[192] = "        except Exception as e:\n"
    lines[193] = "            print(f\"Volume read error: {e}\")\n"

with open("emu.py", "w") as f:
    f.writelines(lines)

print("Exact indentation and try/except block repaired!")
