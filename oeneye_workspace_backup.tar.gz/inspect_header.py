with open("oeneye-00x00.img", "rb") as f:
    sector = f.read(512)
    print("--- HEX DUMP (First 64 bytes) ---")
    print(sector[:64].hex())
    print("\n--- ASCII STRINGS FOUND IN FIRST SECTOR ---")
    printable = "".join([chr(b) if 32 <= b < 127 else '.' for b in sector])
    # Print in chunks of 64 characters
    for i in range(0, len(printable), 64):
        print(printable[i:i+64])
