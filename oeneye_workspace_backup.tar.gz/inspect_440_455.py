with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(439, min(456, len(lines))):
    print(f"{i+1:3d}: {repr(lines[i])}")
