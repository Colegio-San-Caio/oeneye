with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 412:
    # Indent the body lines under the if statement (lines 410 and 411)
    lines[410] = "        env_state[\"active_idx\"] = idx\n"
    lines[411] = "        print(f\"Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}\")\n"
    print("Indented if body blocks correctly!")

with open("emu.py", "w") as f:
    f.writelines(lines)
