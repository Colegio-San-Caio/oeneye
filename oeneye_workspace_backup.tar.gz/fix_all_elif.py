with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(len(lines)):
    if "elif " in lines[i] and not lines[i].strip().startswith("#"):
        # Check if there is a preceding 'if' or 'elif' at the same indentation level before the previous block
        # To be safe and robust in this CLI loop structure, convert orphaned elifs to if
        lines[i] = lines[i].replace("elif", "if")
        print(f"Converted elif to if at line {i+1}")

with open("emu.py", "w") as f:
    f.writelines(lines)

print("All elif statements normalized!")
