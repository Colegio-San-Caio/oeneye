with open("emu.py", "r") as f:
    code = f.read()

# Replace the DISKINFO block with proper top-level global declaration
old_diskinfo = """        elif cmd.upper().startswith("DISKINFO"):
            import os
            # Use globally tracked active volume if available, or default to current mount map
            if 'active_volume_img' not in globals():
                global active_volume_img
                active_volume_img = "oeneye-mosfetq-fat32.img"
            else:
                global active_volume_img"""

new_diskinfo = """        elif cmd.upper().startswith("DISKINFO"):
            global active_volume_img
            import os
            if 'active_volume_img' not in globals():
                active_volume_img = "oeneye-mosfetq-fat32.img\""""

# Let's replace the whole DISKINFO implementation cleanly
if "elif cmd.upper().startswith(\"DISKINFO\"):" in code:
    import re
    # Match from DISKINFO up to the next elif
    pattern = r'elif cmd\.upper\(\)\.startswith\("DISKINFO"\):.*?(?=\n\s+elif|f\.write|#|$)'
    replacement = """elif cmd.upper().startswith("DISKINFO"):
            global active_volume_img
            import os
            if 'active_volume_img' not in globals():
                active_volume_img = "oeneye-mosfetq-fat32.img"
            if os.path.exists(active_volume_img):
                print(f"--- Volume Inspection: {active_volume_img} ---")
                with open(active_volume_img, "rb") as img_file:
                    boot_sector = img_file.read(512)
                print(f"Boot Sector Size Read: {len(boot_sector)} bytes")
                print(f"Signature / Magic: {boot_sector[-2:].hex()}")
                print("Status: Superblock parsed successfully. Volume architecture active.")
            else:
                print(f"Error: Volume image {active_volume_img} not found.")"""
    code = re.sub(pattern, replacement, code, flags=re.DOTALL)

with open("emu.py", "w") as f:
    f.write(code)

print("Scope fixed successfully!")
