with open("emu.py", "r") as f:
    code = f.read()

# Remove the global statement and use globals() dictionary directly
code = code.replace("global memory", "")
code = code.replace('if "memory" not in globals():\n                memory = bytearray(0x10000)', 'if "memory" not in globals():\n                globals()["memory"] = bytearray(0x10000)\n            memory = globals()["memory"]')

with open("emu.py", "w") as f:
    f.write(code)

print("Cleaned up scope handling!")
