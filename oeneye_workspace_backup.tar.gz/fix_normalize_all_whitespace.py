with open("emu.py", "r") as f:
    content = f.read()

# Replace all tabs with 4 spaces to prevent hidden mixing issues
content = content.replace("\t", "    ")

with open("emu.py", "w") as f:
    f.write(content)

print("Normalized all tabs to spaces across the entire file!")
