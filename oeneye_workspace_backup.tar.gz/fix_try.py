with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(200, len(lines)):
    if lines[i].strip() == "try:":
        lines[i] = "# " + lines[i]
        print(f"Neutralized try: at line {i+1}")

with open("emu.py", "w") as f:
    f.writelines(lines)

print("Cleanup complete!")
