with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 350:
    idx = 349  # 0-indexed for line 350
    if "except" in lines[idx] and not lines[idx].strip().startswith("#"):
        lines[idx] = "# " + lines[idx]
        print("Neutralized orphaned except block at line 350!")

with open("emu.py", "w") as f:
    f.writelines(lines)
