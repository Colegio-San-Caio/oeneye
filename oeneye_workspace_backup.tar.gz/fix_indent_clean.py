with open("emu.py", "r") as f:
    lines = f.readlines()

fixed = []
for line in lines:
    if "except (KeyboardInterrupt, EOFError):" in line:
        # Flush left to match the outer execution loop block level
        fixed.append("except (KeyboardInterrupt, EOFError):\n")
    else:
        fixed.append(line)

with open("emu.py", "w") as f:
    f.writelines(fixed)

print("Flush-aligned exception handler successfully!")
