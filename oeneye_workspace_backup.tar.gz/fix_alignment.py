with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 413:
    # Ensure line 409 and line 412 share the exact same indentation (4 spaces)
    lines[409] = "    if idx < len(mounted):\n"
    lines[412] = "    else:\n"
    print("Aligned if and else indentation perfectly!")

with open("emu.py", "w") as f:
    f.writelines(lines)
