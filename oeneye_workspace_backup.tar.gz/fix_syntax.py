with open("emu.py", "r") as f:
    code = f.read()

# Replace the broken section by cleanly inserting STRINGS right before FAT
old_target = 'elif cmd_upper == "FAT":'
new_block = '''elif cmd_upper == "STRINGS" or cmd_upper == "DUMP":
                import re
                print("Scanning binary image for ASCII strings (min length 4)...")
                pattern = b"[ -~]{4,}"
                matches = re.findall(pattern, img)
                for idx, match in enumerate(matches):
                    try:
                        text = match.decode("ascii")
                        print(f"  [{idx:03d}] {text}")
                    except UnicodeDecodeError:
                        continue
            elif cmd_upper == "FAT":'''

if old_target in code and "STRINGS" not in code:
    code = code.replace(old_target, new_block, 1)
    with open("emu.py", "w") as f:
        f.write(code)
    print("SUCCESS: Successfully integrated STRINGS command!")
else:
    print("Note: STRINGS already present or target not found. Checking syntax...")

