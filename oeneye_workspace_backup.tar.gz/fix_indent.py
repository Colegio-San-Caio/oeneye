with open("emu.py", "r") as f:
    lines = f.readlines()

new_lines = []
i = 0
while i < len(lines):
    line = lines[i]
    if 'if mnemonic.startswith("MOV AH"):' in line:
        indent = "                    "
        new_lines.append(indent + 'if mnemonic.startswith("MOV AH"):\n')
        new_lines.append(indent + '    val = parse_hex(args[-1])\n')
        new_lines.append(indent + '    encoded = bytes([0xB4, val & 0xFF])\n')
        new_lines.append(indent + 'elif mnemonic.startswith("MOV BX"):\n')
        new_lines.append(indent + '    val = parse_hex(args[-1])\n')
        new_lines.append(indent + '    encoded = bytes([0xBB]) + struct.pack("<H", val & 0xFFFF)\n')
        new_lines.append(indent + 'elif mnemonic.startswith("MOV DX"):\n')
        new_lines.append(indent + '    val = parse_hex(args[-1])\n')
        new_lines.append(indent + '    encoded = bytes([0xBA]) + struct.pack("<H", val & 0xFFFF)\n')
        new_lines.append(indent + 'elif mnemonic == "MOV AX, [BX]":\n')
        new_lines.append(indent + '    encoded = bytes([0xA5])\n')
        new_lines.append(indent + 'elif mnemonic == "MOV [BX], AX":\n')
        new_lines.append(indent + '    encoded = bytes([0xA7])\n')
        new_lines.append(indent + 'elif mnemonic.startswith("MOV AX, ["):\n')
        new_lines.append(indent + '    target_addr = parse_hex(mnemonic.split("[")[1].split("]")[0])\n')
        new_lines.append(indent + '    encoded = bytes([0xA1]) + struct.pack("<H", target_addr & 0xFFFF)\n')
        new_lines.append(indent + 'elif mnemonic.startswith("MOV ["):\n')
        new_lines.append(indent + '    target_addr = parse_hex(mnemonic.split("[")[1].split("]")[0])\n')
        new_lines.append(indent + '    encoded = bytes([0xA3]) + struct.pack("<H", target_addr & 0xFFFF)\n')
        new_lines.append(indent + 'elif mnemonic.startswith("MOV AX"):\n')
        new_lines.append(indent + '    val = parse_hex(args[-1])\n')
        new_lines.append(indent + '    encoded = bytes([0xB8]) + struct.pack("<H", val & 0xFFFF)\n')
        
        i += 1
        while i < len(lines) and 'elif mnemonic.startswith("CMP AX"):' not in lines[i]:
            i += 1
        continue
    else:
        new_lines.append(line)
        i += 1

with open("emu.py", "w") as f:
    f.writelines(new_lines)

print("Indentation fixed successfully!")
