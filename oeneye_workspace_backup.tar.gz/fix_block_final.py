with open("emu.py", "r") as f:
    lines = f.readlines()

new_lines = []
skip = False
for i, line in enumerate(lines):
    # Detect where the problematic chunk-reading download check starts
    if "f.read(1 << 20)" in line or ("if not chunk:" in line and i < 80):
        # Insert a clean, properly indented block once
        new_lines.append("            chunk = f.read(1 << 20)\n")
        new_lines.append("            if not chunk:\n")
        new_lines.append("                break\n")
        new_lines.append("            h.update(chunk)\n")
        # Skip the next few legacy raw lines if they match
        continue
    if skip and i < 75:
        if "h.update" in line or "break" in line or "if not chunk" in line:
            continue
        else:
            skip = False
    new_lines.append(line)

with open("emu.py", "w") as f:
    f.writelines(new_lines)

print("Block rewritten cleanly!")
