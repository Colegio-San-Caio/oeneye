import os
import struct
import sys

IMAGE_PATH = "mosfetq-dos.img"
current_path = "A:\\"
current_cluster = 0

def print_banner():
    print("Loading MOSFETQ DOS...")
    print()
    print("MOSFETQ DOS 0.2")
    print("Type HELP for a list of commands.")
    print()

def get_disk_geometry(f):
    f.seek(11)
    bytes_per_sec = struct.unpack("<H", f.read(2))[0]
    sec_per_clus = f.read(1)[0]
    reserved_sec = struct.unpack("<H", f.read(2))[0]
    num_fats = f.read(1)[0]
    root_entries = struct.unpack("<H", f.read(2))[0]
    f.seek(22)
    sec_per_fat = struct.unpack("<H", f.read(2))[0]
    root_dir_sector = reserved_sec + (num_fats * sec_per_fat)
    root_dir_offset = root_dir_sector * bytes_per_sec
    root_dir_sectors = (root_entries * 32 + bytes_per_sec - 1) // bytes_per_sec
    data_start_sector = root_dir_sector + root_dir_sectors
    return {
        "bytes_per_sec": bytes_per_sec,
        "reserved_sec": reserved_sec,
        "num_fats": num_fats,
        "sec_per_fat": sec_per_fat,
        "root_dir_offset": root_dir_offset,
        "root_entries": root_entries,
        "data_start_sec": data_start_sector,
        "sec_per_clus": sec_per_clus
    }

def find_free_cluster(f, geo):
    fat_offset = geo["reserved_sec"] * geo["bytes_per_sec"]
    f.seek(fat_offset)
    fat_data = f.read(geo["sec_per_fat"] * geo["bytes_per_sec"])
    for cluster in range(2, 4086):
        byte_idx = int(cluster * 1.5) if len(fat_data) > 4096 else cluster * 2
        if byte_idx + 2 > len(fat_data):
            break
        val = struct.unpack("<H", fat_data[byte_idx:byte_idx+2])[0]
        if (val & 0xFFF) == 0x000:
            return cluster
    return 5

def run_dir():
    if not os.path.exists(IMAGE_PATH):
        print("[-] Error: Volume image missing.")
        return
    with open(IMAGE_PATH, "rb") as f:
        geo = get_disk_geometry(f)
        if current_cluster == 0:
            f.seek(geo["root_dir_offset"])
            dir_data = f.read(geo["root_entries"] * 32)
        else:
            cluster_offset = (geo["data_start_sec"] + (current_cluster - 2) * geo["sec_per_clus"]) * geo["bytes_per_sec"]
            f.seek(cluster_offset)
            dir_data = f.read(geo["sec_per_clus"] * geo["bytes_per_sec"])
        print(f"\n Volume in drive A has no label.")
        print(f" Directory of {current_path}\n")
        count = 0
        total_bytes = 0
        for i in range(0, len(dir_data), 32):
            entry = dir_data[i:i+32]
            if entry[0] == 0x00:
                break
            if entry[0] == 0xE5 or entry[11] == 0x0F:
                continue
            attr = entry[11]
            if attr not in (0x10, 0x20, 0x00, 0x01, 0x02, 0x04):
                continue
            name = entry[0:8].decode("ascii", errors="ignore").strip()
            ext = entry[8:11].decode("ascii", errors="ignore").strip()
            size = struct.unpack("<I", entry[28:32])[0]
            if not (attr & 0x10) and size > 10 * 1024 * 1024:
                continue
            if attr & 0x10:
                if name in (".", ".."):
                    continue
                print(f" {name.ljust(12)}   <DIR>")
            else:
                filename = f"{name}.{ext}" if ext else name
                print(f" {filename.ljust(12)} {str(size).rjust(10)} bytes")
                total_bytes += size
            count += 1
        print(f"\n   {count} item(s)     {total_bytes} bytes")
        print()

def run_tree():
    if not os.path.exists(IMAGE_PATH):
        print("[-] Error: Volume image missing.")
        return
    with open(IMAGE_PATH, "rb") as f:
        geo = get_disk_geometry(f)
        print(f"\nFolder PATH listing for volume MOSFETQ_DOS")
        print(f"Volume serial number is 0426-DEAD")
        def print_sub_tree(clus, indent=""):
            if clus == 0:
                f.seek(geo["root_dir_offset"])
                dir_data = f.read(geo["root_entries"] * 32)
            else:
                cluster_offset = (geo["data_start_sec"] + (clus - 2) * geo["sec_per_clus"]) * geo["bytes_per_sec"]
                f.seek(cluster_offset)
                dir_data = f.read(geo["sec_per_clus"] * geo["bytes_per_sec"])
            entries = []
            for i in range(0, len(dir_data), 32):
                entry = dir_data[i:i+32]
                if entry[0] == 0x00: break
                if entry[0] == 0xE5 or entry[11] == 0x0F: continue
                attr = entry[11]
                if attr not in (0x10, 0x20, 0x00, 0x01, 0x02, 0x04): continue
                name = entry[0:8].decode("ascii", errors="ignore").strip()
                ext = entry[8:11].decode("ascii", errors="ignore").strip()
                sub_clus = struct.unpack("<H", entry[26:28])[0]
                entries.append((name, ext, attr, sub_clus))
            dirs = [e for e in entries if (e[2] & 0x10) and e[0] not in (".", "..")]
            files = [e for e in entries if not (e[2] & 0x10)]
            all_items = dirs + files
            for idx, (name, ext, attr, sub_clus) in enumerate(all_items):
                is_last = (idx == len(all_items) - 1)
                connector = "└── " if is_last else "├── "
                next_indent = indent + ("    " if is_last else "│   ")
                if attr & 0x10:
                    print(f"{indent}{connector}[{name}]")
                    print_sub_tree(sub_clus if sub_clus != 0 else 6, next_indent)
                else:
                    filename = f"{name}.{ext}" if ext else name
                    print(f"{indent}{connector}{filename}")
        print_sub_tree(current_cluster)
        print()

def run_cd(target):
    global current_path, current_cluster
    target = target.upper()
    if not os.path.exists(IMAGE_PATH):
        print("[-] Error: Volume image missing.")
        return
    with open(IMAGE_PATH, "rb") as f:
        geo = get_disk_geometry(f)
        if target == "..":
            if current_cluster == 0:
                return
            cluster_offset = (geo["data_start_sec"] + (current_cluster - 2) * geo["sec_per_clus"]) * geo["bytes_per_sec"]
            f.seek(cluster_offset + 32)
            dotdot_entry = f.read(32)
            parent_cluster = struct.unpack("<H", dotdot_entry[26:28])[0]
            current_cluster = 0 if parent_cluster == 6 or parent_cluster == 0 else parent_cluster
            current_path = "A:\\"
            return
        if current_cluster == 0:
            f.seek(geo["root_dir_offset"])
            dir_data = f.read(geo["root_entries"] * 32)
        else:
            cluster_offset = (geo["data_start_sec"] + (current_cluster - 2) * geo["sec_per_clus"]) * geo["bytes_per_sec"]
            f.seek(cluster_offset)
            dir_data = f.read(geo["sec_per_clus"] * geo["bytes_per_clus"])
        found = False
        for i in range(0, len(dir_data), 32):
            entry = dir_data[i:i+32]
            if entry[0] == 0x00:
                break
            if entry[0] == 0xE5 or entry[11] == 0x0F:
                continue
            name = entry[0:8].decode("ascii", errors="ignore").strip()
            attr = entry[11]
            if name == target and (attr & 0x10):
                cluster = struct.unpack("<H", entry[26:28])[0]
                current_cluster = cluster if cluster != 0 else 6
                current_path = f"{current_path}{name}\\"
                found = True
                break
        if not found:
            print(f"Directory not found - {target}")


def run_map():
    if not os.path.exists(IMAGE_PATH):
        print("[-] Error: Volume image missing.")
        return
    with open(IMAGE_PATH, "rb") as f:
        geo = get_disk_geometry(f)
        fat_offset = geo['reserved_sec'] * geo['bytes_per_sec']
        f.seek(fat_offset)
        fat_data = f.read(geo['sec_per_fat'] * geo['bytes_per_sec'])
        print(f"\n--- FAT CLUSTER MAP (First 128 clusters) ---")
        cluster_grid = []
        for cluster in range(0, 128):
            if cluster < 2:
                status = "R"
            else:
                byte_idx = int(cluster * 1.5) if len(fat_data) > 4096 else cluster * 2
                if byte_idx + 2 <= len(fat_data):
                    val = struct.unpack("<H", fat_data[byte_idx:byte_idx+2])[0]
                    if len(fat_data) <= 4096:
                        val = val & 0xFFF
                    if val == 0x000:
                        status = "."
                    elif val >= 0xFF8:
                        status = "E"
                    else:
                        status = "X"
                else:
                    status = "?"
            cluster_grid.append(status)
        for r in range(0, len(cluster_grid), 32):
            row_str = " ".join(cluster_grid[r:r+32])
            print(f"{r:03X}: {row_str}")
        print("Legend: [.] Free  [X] Allocated  [E] End-Chain  [R] Reserved")
        print("-" * 65)

def main():
    print_banner()
    while type(current_path) == str:
        try:
            line = input(f"{current_path}> ")
        except EOFError:
            break
        parts = line.strip().split()
        if not parts:
            continue
        cmd = parts[0].upper()
        args = parts[1:]
        if cmd == "DIR":
            run_dir()
        elif cmd == "TREE":
            run_tree()
        elif cmd == "MAP":
            run_map()
        elif cmd == "CD":
            if args: run_cd(args[0])
            else: print("Required parameter missing")
        elif cmd == "HELP":
            print("Available commands: DIR, TREE, MAP, CD <dir>, CLS, EXIT")
        elif cmd == "CLS":
            os.system("clear" if os.name == "posix" else "cls")
        elif cmd == "EXIT":
            break
        else:
            print(f"Bad command or file name: {cmd}")

if __name__ == "__main__":
    main()
