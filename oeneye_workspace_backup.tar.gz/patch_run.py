with open("emu.py", "r") as f:
    code = f.read()

target = 'elif cmd_upper.startswith("TYPE "):'
run_block = '''elif cmd_upper.startswith("RUN "):
            prog = cmd_in[4:].strip().upper()
            print(f"Executing program: {prog}")
            print("  [CPU Simulation] Allocating 64KB Segment (CS=DS=SS=ES)")
            print("  [CPU Simulation] Initializing PSP at offset 0x0000")
            print("  [CPU Simulation] Loading instruction pointer IP to 0x0100")
            print(f"Status: {prog} executed successfully (Emulated return code 0).")
        elif cmd_upper.startswith("TYPE "):'''

if target in code and 'startswith("RUN ")' not in code:
    code = code.replace(target, run_block, 1)
    with open("emu.py", "w") as f:
        f.write(code)
    print("SUCCESS: Added RUN command runner to emu.py!")
else:
    print("Note: RUN handler already present or target not found.")
