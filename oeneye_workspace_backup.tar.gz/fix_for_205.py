with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 205:
    # Ensure line 205 (index 204) has proper inner indentation
    stripped = lines[204].lstrip()
    lines[204] = "                " + stripped

with open("emu.py", "w") as f:
    f.writelines(lines)

print("For loop body indentation fixed!")
