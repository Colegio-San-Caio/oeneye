with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 415:
    # Replace lines around 413-415 with a properly structured try/except block
    lines[412] = "    try:\n"
    lines[413] = "        drive_target = cmd.upper().strip()\n"
    lines[414] = "        print(f'Drive {drive_target} is not mounted.')\n"
    # Ensure the except follows immediately
    if "except" not in lines[415]:
        lines.insert(415, "    except Exception as e:\n")
        lines.insert(416, f"        print(f'Error: {{e}}')\n")
    print("Structured try...except block correctly!")

with open("emu.py", "w") as f:
    f.writelines(lines)
