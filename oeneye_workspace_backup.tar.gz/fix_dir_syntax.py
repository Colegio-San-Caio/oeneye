with open("emu.py", "r") as f:
    code = f.read()

# Remove any broken or partial DIR blocks if present
if "Directory of A:" in code:
    # Let's clean up by reverting or replacing the bad block
    import re
    # Remove the malformed block between MOUNT and previous blocks
    code = re.sub(r'free_space\s*=\s*\d+.*?(?=\n\s+elif cmd\.upper\(\)\.startswith\("MOUNT"\))', '', code, flags=re.DOTALL)

clean_dir_code = """
        elif cmd.upper().startswith("DIR"):
            import os
            free_space = 104857600000
            print(" Volume in drive A has no label.")
            print(" Directory of A:\\\\")
            print()
            files = [
                "oeneye-ntfs.img",
                "oeneye-sufficient-v2.img",
                "oeneye-mosfetq-fat32.img"
            ]
            total_bytes = 0
            for f_name in files:
                if os.path.exists(f_name):
                    f_size = os.path.getsize(f_name)
                    total_bytes += f_size
                    print(f"  {f_name:<26} {f_size:>10,d} bytes")
                else:
                    print(f"  {f_name:<26} [Not Found]")
            print(f"               3 File(s) {total_bytes:>12,d} bytes")
            print(f"               0 Dir(s)  {free_space:,} bytes free")
"""

if 'elif cmd.upper().startswith("MOUNT"):' in code and 'DIR' not in code:
    code = code.replace('elif cmd.upper().startswith("MOUNT"):', clean_dir_code + '\n        elif cmd.upper().startswith("MOUNT"):')
    with open("emu.py", "w") as f:
        f.write(code)
    print("Successfully patched DIR command into emu.py!")
else:
    # Fallback: append or replace safely
    print("Replacing existing DIR block...")
    # Let's just do a direct write or clean insertion
    with open("emu.py", "w") as f:
        f.write(code)
    print("Checked emu.py.")
