with open("emu.py", "r") as f:
    code = f.read()

# Locate where the REPL loop starts
repl_start = 'while True:'
if repl_start in code:
    header = code.split(repl_start)[0]
    
    new_repl = '''while True:
        try:
            cmd_in = input("A:\\\\").strip()
            if not cmd_in:
                continue
            if cmd_in.upper().startswith("A:\\\\"):
                cmd_in = cmd_in[3:].strip()
            
            cmd_upper = cmd_in.upper()
            
            if cmd_upper == "EXIT":
                print("Exiting AI Core Bridge...")
                break
            elif cmd_upper == "CLS":
                print("\\033[H\\033[J", end="")
            elif cmd_upper == "VER":
                print("MOSFETQ DOS 0.1 (512-byte block architecture)")
                print("Runtime: Python Emulated Environment (Composite LBA Mapped)")
            elif cmd_upper == "DIR":
                boot_sector = img[:BLOCK_SIZE]
                bytes_per_sec = struct.unpack("<H", boot_sector[11:13])[0]
                rsvd_sec_cnt = struct.unpack("<H", boot_sector[14:16])[0]
                num_fats = boot_sector[16]
                root_ent_cnt = struct.unpack("<H", boot_sector[17:19])[0]
                fat_sz_16 = struct.unpack("<H", boot_sector[22:24])[0]
                if bytes_per_sec == 0:
                    bytes_per_sec = 512
                first_root_sec = rsvd_sec_cnt + (num_fats * fat_sz_16)
                root_dir_bytes = root_ent_cnt * 32
                start_offset = first_root_sec * bytes_per_sec
                end_offset = start_offset + root_dir_bytes
                print(" Volume in drive A has live FAT structure.")
                print(" Directory of A:\\\\")
                file_count = 0
                total_bytes = 0
                if start_offset < len(img):
                    root_data = img[start_offset:min(end_offset, len(img))]
                    for i in range(0, len(root_data), 32):
                        entry = root_data[i:i+32]
                        if len(entry) < 32 or entry[0] == 0x00:
                            break
                        if entry[0] == 0xE5 or entry[11] == 0x0F or (entry[11] & 0x08):
                            continue
                        name = entry[0:8].decode("ascii", errors="ignore").strip()
                        ext = entry[8:11].decode("ascii", errors="ignore").strip()
                        fsize = struct.unpack("<I", entry[28:32])[0]
                        filename_str = f"{name} {ext}" if ext else name
                        print(f"  {filename_str:12s} {fsize:9d}")
                        file_count += 1
                        total_bytes += fsize
                print(f"         {file_count} File(s)      {total_bytes} bytes")
                print(f"                     {len(img) - total_bytes:10d} bytes free")
            elif cmd_upper == "MBR":
                boot_sector = img[:BLOCK_SIZE]
                sig_hex = boot_sector[510:512].hex()
                print("Master Boot Record (MBR) Analysis:")
                print(f"  Boot Signature (offset 510): 0x{sig_hex}")
                if boot_sector[510] == 0x55 and boot_sector[511] == 0xaa:
                    print("  Status: Valid MBR signature (0x55AA) verified.")
                else:
                    print("  Status: Non-standard or raw image sector.")
                part_entry = boot_sector[446:462]
                if len(part_entry) >= 16:
                    status = part_entry[0]
                    ptype = part_entry[4]
                    start_lba = struct.unpack("<I", part_entry[8:12])[0]
                    sectors = struct.unpack("<I", part_entry[12:16])[0]
                    print(f"  Partition 1 -> Type: 0x{ptype:02X}, Start LBA: {start_lba}, Sectors: {sectors}")
            elif cmd_upper == "FAT":
                boot_sector = img[:BLOCK_SIZE]
                bytes_per_sec = struct.unpack("<H", boot_sector[11:13])[0]
                sec_per_clust = boot_sector[13]
                rsvd_sec_cnt = struct.unpack("<H", boot_sector[14:16])[0]
                num_fats = boot_sector[16]
                root_ent_cnt = struct.unpack("<H", boot_sector[17:19])[0]
                fat_sz_16 = struct.unpack("<H", boot_sector[22:24])[0]
                print("FAT Filesystem Analysis (BPB):")
                print(f"  Bytes per Sector: {bytes_per_sec}")
                print(f"  Sectors per Cluster: {sec_per_clust}")
                print(f"  Reserved Sectors: {rsvd_sec_cnt}")
                print(f"  Number of FATs: {num_fats}")
                print(f"  Root Directory Entries: {root_ent_cnt}")
                print(f"  FAT Size (Sectors): {fat_sz_16}")
            elif cmd_upper.startswith("LBA ") or cmd_upper.startswith("TYPE LBA "):
                parts = cmd_in.split()
                try:
                    lba_idx = int(parts[-1])
                    start_offset = lba_idx * BLOCK_SIZE
                    end_offset = start_offset + BLOCK_SIZE
                    if start_offset >= len(img):
                        print(f"Error: LBA {lba_idx} exceeds image bounds.")
                    else:
                        block = img[start_offset:end_offset]
                        print(f"Displaying LBA {lba_idx} (Offset {start_offset} - {end_offset}):")
                        print(block[:64].hex() + "...")
                except ValueError:
                    print("Usage: LBA <sector_number>")
            elif cmd_upper.startswith("TYPE "):
                filename = cmd_in[5:].strip().upper()
                if "MOSFETQ" in filename or "IMG" in filename:
                    block = img[:BLOCK_SIZE]
                    print("Displaying LBA 0 (512-byte block alignment):")
                    print(block[:64].hex() + "...")
                else:
                    print(f"Composite block error: File not found or unmapped - {filename}")
            elif cmd_upper.startswith("GEMINI"):
                sub_q = cmd_in[6:].strip()
                print(f"AI Core Bridge: Query received -> '{sub_q}'")
                print("Status: 512-byte alignment verified. System invariants intact.")
            else:
                print(f"Command not recognized: {cmd_in}")
        except (KeyboardInterrupt, EOFError):
            print()
            break
'''
    with open("emu.py", "w") as f:
        f.write(header + new_repl)
    print("SUCCESS: REPL loop cleanly restructured!")
else:
    print("Error: Could not find REPL loop.")
