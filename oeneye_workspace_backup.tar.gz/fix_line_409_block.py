with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 416:
    lines[408] = "        if idx < len(mounted):\n"
    lines[409] = "            env_state['active_idx'] = idx\n"
    lines[410] = "            print(f'Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}')\n"
    lines[411] = "        else:\n"
    lines[412] = "            drive_target = cmd.upper().strip()\n"
    lines[413] = "            print(f'Drive {drive_target} is not mounted.')\n"
    print("Corrected indentation for lines 409-414 successfully!")

with open("emu.py", "w") as f:
    f.writelines(lines)
