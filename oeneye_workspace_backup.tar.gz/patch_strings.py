with open("emu.py", "r") as f:
    code = f.read()

target = 'elif cmd_upper == "FAT":'
if target in code:
    parts = code.split(target)
    header = parts[0]
    tail = parts[1]
    
    strings_code = '''elif cmd_upper == "STRINGS" or cmd_upper == "DUMP":
                import re
                print("Scanning binary image for ASCII strings (min length 4)...")
                # Find all sequences of 4 or more printable ASCII characters
                pattern = b"[ -~]{4,}"
                matches = re.findall(pattern, img)
                for idx, match in enumerate(matches):
                    try:
                        text = match.decode("ascii")
                        print(f"  [{idx:03d}] {text}")
                    except UnicodeDecodeError:
                        continue
    elif cmd_upper == "FAT":
'''
    
    new_code = header + strings_code + tail
    with open("emu.py", "w") as f:
        f.write(new_code)
    print("SUCCESS: Added STRINGS command to emu.py!")
else:
    print("Error: Could not locate FAT target in emu.py.")
