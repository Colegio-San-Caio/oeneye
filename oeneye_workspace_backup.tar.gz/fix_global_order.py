with open("emu.py", "r") as f:
    code = f.read()

# Put global memory right at the top of the TESTECH block
old_block = """        elif cmd.upper() == "TESTECH":
            print("--- Testing INT 21h AH=0Ah (Input) + AH=09h (Output) ---")
            global memory
            if "memory" not in globals():"""

new_block = """        elif cmd.upper() == "TESTECH":
            global memory
            print("--- Testing INT 21h AH=0Ah (Input) + AH=09h (Output) ---")
            if "memory" not in globals():"""

code = code.replace(old_block, new_block)

with open("emu.py", "w") as f:
    f.write(code)

print("Fixed global declaration order!")
