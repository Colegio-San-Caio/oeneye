import struct

with open("oeneye-ext4.img", "rb") as f:
    f.seek(1048)
    block_size = 1024 << struct.unpack("<I", f.read(4))[0]
    
    # Read root inode
    f.seek(143360 + 256)
    inode_data = f.read(256)
    
    i_block = inode_data[40:100]
    if struct.unpack("<H", i_block[0:2])[0] == 0xf30a:
        ee_start_lo = struct.unpack("<I", i_block[16:20])[0]
        f.seek(ee_start_lo * block_size)
        data = f.read(block_size)
        
        print("  [EXT4] Scanning for valid file inodes...")
        offset = 0
        while offset < block_size - 8:
            header = data[offset:offset+8]
            inode_val, rec_len, name_len, file_type = struct.unpack("<IHBB", header)
            if rec_len == 0:
                break
            
            # Look for valid non-zero inodes with actual names
            if inode_val > 0 and name_len > 0 and name_len < 255:
                name = data[offset+8 : offset+8+name_len].decode('utf-8', errors='ignore')
                print(f"    -> Found Active Entry: {name} (Inode: {inode_val}, Type: {file_type})")
                
            offset += rec_len
