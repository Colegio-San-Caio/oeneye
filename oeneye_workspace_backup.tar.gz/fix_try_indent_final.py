with open("emu.py", "r") as f:
    lines = [line.rstrip('\n') for line in f.readlines()]

# Wir behalten den stabilen Code bis vor dem fehlerhaften Block bei
clean_lines = [l for i, l in enumerate(lines) if i < 477]

# Sauber ausgerichteter Leinöl- und Ausnahmefang-Block
tail_block = [
    "try:",
    "    # Leinöl (Linseed Oil) Polymer Viscosity & Smoothing Coefficient",
    "    leinol_viscosity_factor = 0.985",
    "    if 'env_state' in globals() and 'tartan_sett_matrix' in env_state:",
    "        env_state['leinol_smoothed'] = [v * leinol_viscosity_factor for v in env_state['tartan_sett_matrix']]",
    "except Exception as leinol_err:",
    "    print(f'Leinöl polymer warning: {leinol_err}')",
    "except (KeyboardInterrupt, EOFError):",
    "    print('\\n[MOSFETQ-DOS] Session stabilized under Leinöl polymer seal.')"
]

clean_lines.extend(tail_block)

with open("emu.py", "w") as f:
    f.write('\n'.join(clean_lines) + '\n')

print("Einrückung für try: und Leinöl-Block erfolgreich bereinigt!")
