import re
with open("emu.py", "r") as f:
    code = f.read()

helper = '''
import time, hashlib, os, platform

def oeneyecuda_cmd(cmd):
    parts = cmd.split()
    sub = parts[1].lower() if len(parts) > 1 else "help"
    img = "oeneye-ntfs.img"
    if sub == "bench":
        n = 48
        a = [[(i * j) % 7 + 1 for j in range(n)] for i in range(n)]
        b = [[(i + j) % 5 + 1 for j in range(n)] for i in range(n)]
        t0 = time.perf_counter()
        c = [[sum(a[i][k] * b[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
        dt = time.perf_counter() - t0
        macs = n ** 3
        print(f"Matmul {n}x{n} (pure Python, CPU): {macs:,} multiply-adds in {dt*1000:.2f} ms ({macs/dt/1e6:.2f} M MAC/s)")
        if os.path.exists(img):
            h = hashlib.sha256()
            size = 0
            t0 = time.perf_counter()
            with open(img, "rb") as f:
                while True:
                    chunk = f.read(1 << 20)
                    if not chunk:
                        break
                    h.update(chunk)
                    size += len(chunk)
            dt = time.perf_counter() - t0
            print(f"SHA-256 of {img}: {size:,} bytes in {dt*1000:.1f} ms ({size/dt/1e6:.1f} MB/s)")
            print(f"Digest: {h.hexdigest()[:32]}...")
        else:
            print(f"{img} not found - skipped hash benchmark.")
    elif sub == "cuda":
        print("--- OENEYECUDA status ---")
        print("Backend: CPU (pure Python). No CUDA device; no GPU offload.")
        print(f"Host: {platform.machine()} / {platform.system()}")
        if os.path.exists(img):
            print(f"Image: {img}, {os.path.getsize(img):,} bytes")
        else:
            print(f"Image: {img} not found")
    else:
        print("Usage: OENEYECUDA bench | OENEYECUDA cuda")
'''

if "def oeneyecuda_cmd" not in code:
    lines = code.split("\n")
    at = 0
    for i, line in enumerate(lines):
        if line.startswith("import ") or line.startswith("from "):
            at = i + 1
    lines.insert(at, helper)
    code = "\n".join(lines)

m = re.search(r'^(\s*)elif cmd\.upper\(\)\.startswith\("OENEYECUDA"\):', code, flags=re.M)
if m and "oeneyecuda_cmd(cmd)" not in code:
    ind = m.group(1)
    new = f'{ind}elif cmd.upper().startswith("OENEYECUDA"):\n{ind}    oeneyecuda_cmd(cmd)\n'
    code = code[:m.start()] + new + code[m.start():]
    print("OENEYECUDA now runs real benchmarks.")
elif not m:
    print("Could not find the OENEYECUDA elif - paste that block and I'll adjust.")

with open("emu.py", "w") as f:
    f.write(code)
