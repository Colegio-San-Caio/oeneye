import re
with open("emu.py", "r") as f:
    code = f.read()

helper = r'''
_FB_W, _FB_H = 320, 200
_FB = bytearray(_FB_W * _FB_H * 4)

def paint_cmd(cmd):
    parts = cmd.split()
    name = parts[0].upper()
    if name == "PAINTCLEAR":
        color = int(parts[1], 0) if len(parts) > 1 else 0x000000FF
        px = bytes([(color >> 24) & 255, (color >> 16) & 255, (color >> 8) & 255, color & 255])
        _FB[:] = px * (_FB_W * _FB_H)
        print("Clearing 320x200 framebuffer at 0xA000:0000 with color 0x%08X (256,000 bytes reset)." % color)
    elif name == "PAINTRECT":
        try:
            x, y, w, h = (int(p) for p in parts[1:5])
            color = int(parts[5], 0)
        except (ValueError, IndexError):
            print("Usage: PAINTRECT <x> <y> <w> <h> <color_hex>")
            return
        px = bytes([(color >> 24) & 255, (color >> 16) & 255, (color >> 8) & 255, color & 255])
        for yy in range(max(y, 0), min(y + h, _FB_H)):
            for xx in range(max(x, 0), min(x + w, _FB_W)):
                i = (yy * _FB_W + xx) * 4
                _FB[i:i+4] = px
        print("Drawing rectangle at (%d,%d) with size %dx%d and color 0x%08X." % (x, y, w, h, color))
    elif name == "PAINTVIEW":
        shades = " .:-=+*#%@"
        cols, rows = 64, 32
        for r in range(rows):
            line = []
            for c in range(cols):
                i = ((r * _FB_H // rows) * _FB_W + (c * _FB_W // cols)) * 4
                b = (_FB[i] + _FB[i+1] + _FB[i+2]) / 765.0
                line.append(shades[int(b * (len(shades) - 1))])
            print("".join(line))
    elif name == "PAINTSAVE":
        path = parts[1] if len(parts) > 1 else "framebuffer.ppm"
        with open(path, "wb") as out:
            out.write(("P6\n%d %d\n255\n" % (_FB_W, _FB_H)).encode())
            out.write(b"".join(bytes(_FB[i:i+3]) for i in range(0, len(_FB), 4)))
        print("Framebuffer written to %s (%dx%d PPM)." % (path, _FB_W, _FB_H))
'''

if "def paint_cmd" not in code:
    lines = code.split("\n")
    at = 0
    for i, line in enumerate(lines):
        if line.startswith("import ") or line.startswith("from "):
            at = i + 1
    lines.insert(at, helper)
    code = "\n".join(lines)

if "PAINT_PATCH_V2" in code:
    print("Already wired.")
else:
    m = re.search(r'^(\s*)elif cmd\.upper\(\)\.startswith\("PAINTCLEAR"\):', code, flags=re.M)
    if m:
        ind = m.group(1)
        new = (f'{ind}elif cmd.upper().startswith(("PAINTCLEAR", "PAINTRECT", "PAINTVIEW", "PAINTSAVE")):  # PAINT_PATCH_V2\n'
               f'{ind}    paint_cmd(cmd)\n')
        code = code[:m.start()] + new + code[m.start():]
        print("Paint commands wired to a real framebuffer.")
    else:
        print("Could not find the PAINTCLEAR elif - run: grep -n PAINT emu.py")

with open("emu.py", "w") as f:
    f.write(code)
