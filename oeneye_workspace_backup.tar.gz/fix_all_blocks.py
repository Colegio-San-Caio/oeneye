with open("emu.py", "r") as f:
    lines = f.readlines()

for i in range(150, len(lines)):
    stripped = lines[i].strip()
    if stripped.endswith(":") and not stripped.startswith("#"):
        current_indent = len(lines[i]) - len(lines[i].lstrip())
        target_indent_str = " " * (current_indent + 4)
        
        # Look ahead for the next non-empty, non-comment line
        j = i + 1
        while j < len(lines):
            next_stripped = lines[j].lstrip()
            if next_stripped and not next_stripped.startswith("#"):
                # If it's not already indented deeper, fix it
                actual_indent = len(lines[j]) - len(lines[j].lstrip())
                if actual_indent <= current_indent:
                    lines[j] = target_indent_str + next_stripped
                    print(f"Indented line {j+1} to match block at line {i+1}")
                break
            j += 1

with open("emu.py", "w") as f:
    f.writelines(lines)

print("Full file block indentation sweep complete!")
