with open("mosfetq-dos.img", "rb") as f:
    header = f.read(64)
    print("Boot Sector Header (Hex):")
    print(header.hex())
