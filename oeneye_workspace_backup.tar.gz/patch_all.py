import subprocess
import os
import hashlib

# 1. Download the upscaled 32M volume image from Zenodo
url = "https://zenodo.org/records/22983037/files/oeneye-upscaled-32m.img?download=1"
fname = "oeneye-upscaled-32m.img"

print(f"Fetching {fname}...")
subprocess.run(["curl", "-L", url, "-o", fname], check=True)
size = os.path.getsize(fname)
sha = hashlib.sha256()
with open(fname, "rb") as f:
    for chunk in iter(lambda: f.read(4096), b""):
        sha.update(chunk)
print(f"Verified {fname} ({size} bytes) | SHA-256: {sha.hexdigest()[:16]}...")

# 2. Fix the indentation error around line 69 cleanly by rebuilding or replacing the block
with open("emu.py", "r") as f:
    code = f.read()

# Replace the broken download/hash snippet with a properly indented version
old_block = """while True:
chunk = f.read(1 << 20)
if not chunk:
break
h.update(chunk)"""

new_block = """while True:
            chunk = f.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)"""

code = code.replace(old_block, new_block)

# Also register upscaled-32m in valid_vols if present
if "upscaled" not in code and "fat32" in code:
    code = code.replace(
        '"fat32": "oeneye-mosfetq-fat32.img"',
        '"upscaled": "oeneye-upscaled-32m.img",\n                    "fat32": "oeneye-mosfetq-fat32.img"'
    )

with open("emu.py", "w") as f:
    f.write(code)

print("Upscaled image downloaded and emu.py successfully fixed!")
