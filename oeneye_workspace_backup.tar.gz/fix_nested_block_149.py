with open("emu.py", "r") as f:
    lines = f.readlines()

if len(lines) >= 156:
    # Ensure line 150 (index 149) properly executes the inner block with 12 spaces
    lines[149] = "            idx = ord(arg) - ord(\"A\")\n"
    lines[150] = "            if idx < len(mounted):\n"
    lines[151] = "                env_state['active_idx'] = idx\n"
    lines[152] = "                print(f'Current drive changed to {cmd.upper().strip()} -> {mounted[idx]}')\n"
    lines[153] = "            else:\n"
    lines[154] = "                drive_target = cmd.upper().strip()\n"
    lines[155] = "                print(f'Drive {drive_target} is not mounted.')\n"
    print("Fixed nested indentation blocks successfully!")

with open("emu.py", "w") as f:
    f.writelines(lines)
