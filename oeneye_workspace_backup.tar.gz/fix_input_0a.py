with open("emu.py", "r") as f:
    code = f.read()

# Replace sys.stdin.readline with direct input() in AH=0Ah handler
old_target = "import sys\n            line_input = sys.stdin.readline().rstrip('\\n') + '\\r'"
new_target = "line_input = input(\"DOS Keyboard Input > \") + '\\r'"

code = code.replace(old_target, new_target)

with open("emu.py", "w") as f:
    f.write(code)

print("Updated AH=0Ah to use interactive input()!")
