with open("emu.py", "r") as f:
    code = f.read()

# Fix the memory offset directly
code = code.replace("ds_dx = 0x10000", "ds_dx = 0x0500")

with open("emu.py", "w") as f:
    f.write(code)

print("Fixed memory offset to 0x0500!")
