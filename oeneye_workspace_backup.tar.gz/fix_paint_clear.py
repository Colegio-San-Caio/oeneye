with open("emu.py", "r") as f:
    code = f.read()

# Let's inspect or rewrite the paintclear block to ensure it checks startswith properly
old_block = """        elif cmd.upper().startswith("PAINTCLEAR"):"""
new_block = """        elif cmd.upper().startswith("PAINTCLEAR"):"""

# Let's make sure it handles parameters and prints properly
fixed_snippet = """
        elif cmd.upper().startswith("PAINTCLEAR"):
            parts = cmd.split()
            color = int(parts[1], 0) if len(parts) > 1 else 0x000000FF
            print(f"Clearing 320x200 framebuffer at 0xA000:0000 with color 0x{color:08X} (256,000 bytes reset).")
        elif cmd.upper().startswith("PAINTRECT"):
            parts = cmd.split()
            if len(parts) == 6:
                try:
                    x, y, w, h, color = int(parts[1]), int(parts[2]), int(parts[3]), int(parts[4]), int(parts[5], 0)
                    print(f"Drawing rectangle at ({x},{y}) with size {w}x{h} and color 0x{color:08X}.")
                except ValueError:
                    print("Usage: PAINTRECT <x> <y> <w> <h> <color_hex>")
            else:
                print("Usage: PAINTRECT <x> <y> <w> <h> <color_hex>")
"""

# Replace the whole section cleanly
if 'elif cmd.upper().startswith("PAINTRECT"):' in code:
    # Replace the old PAINTRECT/PAINTCLEAR section with the corrected one
    import re
    code = re.sub(r'elif cmd\.upper\(\)\.startswith\("PAINTCLEAR"\):.*?(?=\n\s+elif|\n\s+else)', fixed_snippet.strip(), code, flags=re.DOTALL)
    with open("emu.py", "w") as f:
        f.write(code)
    print("Corrected PAINTCLEAR parser block!")
else:
    print("Could not locate PAINTRECT block for replacement.")
