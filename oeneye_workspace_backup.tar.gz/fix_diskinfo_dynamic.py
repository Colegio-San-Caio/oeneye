with open("emu.py", "r") as f:
    code = f.read()

old_diskinfo = """        elif cmd.upper().startswith("DISKINFO"):
            import os
            # Determine active image based on previous MOUNT or default to fat32
            active_img = "oeneye-mosfetq-fat32.img"
            if os.path.exists(active_img):
                print(f"--- Volume Inspection: {active_img} ---")
                with open(active_img, "rb") as img_file:
                    boot_sector = img_file.read(512)
                print(f"Boot Sector Size Read: {len(boot_sector)} bytes")
                print(f"Signature / Magic: {boot_sector[-2:].hex()}")
                print("Status: Superblock parsed successfully. File allocation table active.")
            else:
                print("Error: No active volume image found.")"""

new_diskinfo = """        elif cmd.upper().startswith("DISKINFO"):
            import os
            # Use globally tracked active volume if available, or default to current mount map
            global active_volume_img
            if 'active_volume_img' not in globals():
                active_volume_img = "oeneye-mosfetq-fat32.img"
            
            if os.path.exists(active_volume_img):
                print(f"--- Volume Inspection: {active_volume_img} ---")
                with open(active_volume_img, "rb") as img_file:
                    boot_sector = img_file.read(512)
                print(f"Boot Sector Size Read: {len(boot_sector)} bytes")
                print(f"Signature / Magic: {boot_sector[-2:].hex()}")
                print("Status: Superblock parsed successfully. Volume architecture active.")
            else:
                print(f"Error: Volume image {active_volume_img} not found.")"""

# Also update the MOUNT command block to set active_volume_img
mount_target = """                if vol in valid_vols:
                    print(f"Successfully mounted active virtual volume: {valid_vols[vol]}")"""

mount_replacement = """                if vol in valid_vols:
                    global active_volume_img
                    active_volume_img = valid_vols[vol]
                    print(f"Successfully mounted active virtual volume: {active_volume_img}")"""

if old_diskinfo in code:
    code = code.replace(old_diskinfo, new_diskinfo)
if mount_target in code:
    code = code.replace(mount_target, mount_replacement)

with open("emu.py", "w") as f:
    f.write(code)

print("Updated DISKINFO for dynamic volume tracking!")
