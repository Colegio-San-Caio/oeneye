with open("emu.py", "r") as f:
    lines = f.readlines()

new_lines = []
inserted = False

for line in lines:
    # Look for where commands like MOUNT or OENEYECUDA are checked
    if 'elif cmd.upper().startswith("MOUNT")' in line and not inserted:
        new_lines.append('        elif cmd.upper() == "DIR" or cmd.upper().startswith("DIR"):\n')
        new_lines.append('            import os\n')
        new_lines.append('            free_space = 104857600000\n')
        new_lines.append('            print(" Volume in drive A has no label.")\n')
        new_lines.append('            print(" Directory of A:\\\\")\n')
        new_lines.append('            print()\n')
        new_lines.append('            files = ["oeneye-ntfs.img", "oeneye-sufficient-v2.img", "oeneye-mosfetq-fat32.img"]\n')
        new_lines.append('            total_bytes = 0\n')
        new_lines.append('            for f_name in files:\n')
        new_lines.append('                if os.path.exists(f_name):\n')
        new_lines.append('                    f_size = os.path.getsize(f_name)\n')
        new_lines.append('                    total_bytes += f_size\n')
        new_lines.append(submission_line := '                    print(f"  {f_name:<26} {f_size:>10,d} bytes")\n')
        new_lines.append('                else:\n')
        new_lines.append('                    print(f"  {f_name:<26} [Not Found]")\n')
        new_lines.append('            print(f"               3 File(s) {total_bytes:>12,d} bytes")\n')
        new_lines.append('            print(f"               0 Dir(s)  {free_space:,} bytes free")\n')
        inserted = True
    new_lines.append(line)

with open("emu.py", "w") as f:
    f.writelines(new_lines)

print("Patch applied successfully:", inserted)
