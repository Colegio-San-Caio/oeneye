with open("emu.py", "r") as f:
    code = f.read()

# Let us replace the AH=0Ah block inside handle_interrupt with a robust, safe version
old_block = """        elif ah == 0x0A:
            import sys
            line = sys.stdin.readline().rstrip("\\n") + "\\r"
            ds_dx = (regs.get("DS", 0) << 4) + regs.get("DX", 0)
            for idx, char in enumerate(line):
                memory[ds_dx + idx] = ord(char)
            return True"""

new_block = """        elif ah == 0x0A:
            import sys
            line = sys.stdin.readline().rstrip("\\n") + "\\r"
            ds = regs.get("DS", 0)
            dx = regs.get("DX", 0)
            ds_dx = (ds << 4) + dx
            max_len = memory[ds_dx] if ds_dx < len(memory) else 30
            # store actual length read (excluding CR or up to max_len)
            input_bytes = line.encode("ascii", errors="ignore")[:max_len]
            memory[ds_dx + 1] = len(input_bytes)
            for idx, b in enumerate(input_bytes):
                memory[ds_dx + 2 + idx] = b
            return True"""

if "elif ah == 0x0A:" in code:
    # Find and replace the AH=0Ah handler section
    parts = code.split("elif ah == 0x0A:")
    # We want to replace from elif ah == 0x0A: to return True
    tail = parts[1].split("return True")[1]
    code = parts[0] + new_block + tail
    with open("emu.py", "w") as f:
        f.write(code)
    print("Patched AH=0Ah handler with safe bounds and length tracking!")
else:
    print("Could not find AH=0Ah handler.")
