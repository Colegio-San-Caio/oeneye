with open("emu.py", "r") as f:
    lines = f.readlines()

fixed = []
for i, line in enumerate(lines):
    # If we hit the outer exception block, ensure a matching try: precedes it
    if line.strip().startswith("except (KeyboardInterrupt, EOFError):"):
        fixed.append("    try:\n")
        fixed.append("        pass\n")
        fixed.append("except (KeyboardInterrupt, EOFError):\n")
        fixed.append("    break\n")
    else:
        fixed.append(line)

with open("emu.py", "w") as f:
    f.writelines(fixed)

print("Wrapped trailing block successfully!")
