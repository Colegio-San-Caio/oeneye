with open("emu.py", "r") as f:
    code = f.read()

old_parse = 'x, y, color = int(parts[1]), int(parts[2]), int(parts[3])'
new_parse = 'x, y, color = int(parts[1]), int(parts[2]), int(parts[3], 0)'

if old_parse in code:
    code = code.replace(old_parse, new_parse)
    with open("emu.py", "w") as f:
        f.write(code)
    print("Fixed hex parsing for PAINTPLOT!")
else:
    print("Could not find parse line.")
