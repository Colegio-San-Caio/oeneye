#!/bin/bash
echo "Initializing terminalMOSFETQ Distribution Environment..."
if [ -f "update_stage.sh" ]; then
    ./update_stage.sh
else
    echo "Error: update_stage.sh not found in distribution root."
fi
