#!/bin/bash
# Complete Lifecycle: Clean, Stage, Backup, URN-indexed Generation, and Autoexec Server

# 0. Terminate any lingering servers on port 8080
pkill -f "http.server 8080" 2>/dev/null

# 1. Staging
mkdir -p ./public
cp -f mosfetq_exchange.ximg.zip ./public/
echo "[$(date)] Staged exchange package to ./public/"

# 2. Backup
mkdir -p ./backups
BACKUP_NAME="./backups/mosfetq_exchange_$(date +%Y%m%d_%H%M%S).zip"
cp mosfetq_exchange.ximg.zip "$BACKUP_NAME"
echo "[$(date)] Created backup at $BACKUP_NAME"

# 3. Dynamic URN-Indexed Generation
cat << 'HTML' > ./public/index.html
<!DOCTYPE html>
<html>
<head>
    <title>terminalMOSFETQ Exchange Hub</title>
    <style>
        body { font-family: monospace; background: #121212; color: #00ff00; padding: 20px; }
        h1, h2 { color: #ffffff; }
        a { color: #00ffff; text-decoration: none; }
        a:hover { text-decoration: underline; }
        ul { list-style-type: square; }
        li { margin: 8px 0; }
        .section { margin-top: 20px; }
        .urn { color: #ff00ff; font-size: 0.9em; }
    </style>
</head>
<body>
    <h1>terminalMOSFETQ & Lemniscate Archive Hub</h1>
    <p>Official DNB URN Registered Exchange & Database Distributions</p>
    
    <div class="section">
        <h2>Active Distributions (By URN)</h2>
        <ul>
            <li>
                <a href="mosfetq_exchange.ximg.zip">mosfetq_exchange.ximg.zip</a><br>
                <span class="urn">URN: urn:nbn:de:101:1-2610011547054.290857796681</span>
            </li>
        </ul>
    </div>

    <div class="section">
        <h2>Archive & Backup Databases</h2>
        <ul>
HTML

for f in ./backups/*.zip; do
    if [ -f "$f" ]; then
        fname=$(basename "$f")
        echo "            <li><a href=\"../backups/$fname\">$fname</a></li>" >> ./public/index.html
    fi
done

cat << 'HTML' >> ./public/index.html
        </ul>
    </div>
</body>
</html>
HTML

echo "[$(date)] Generated URN-indexed page and backup lists."

# 4. Autoexec (Start Server)
echo "[$(date)] Starting local hosting server on port 8080..."
python3 -m http.server 8080 --directory ./public
